$( () =>{

    let clientesDAO= new ClientesDAOfetch();

    let viewModel = {
        clientes: [],   //Client list
        cliente: {},    //Current client
        errMsgs: []     //JSON error from JAX-RS webservice
    };

    let ctrl=new ClienteCtrl(viewModel, clientesDAO);
    window.ctrl = new ClienteCtrl();
    ctrl.init();
});

class ClienteCtrl {
    constructor (vm, clientesDAO) {
        this.clientesDAO=clientesDAO; // DAO injection
        this.model=vm;
        this.config = {
            lista: "#listaClientes",
            formulario: "form[name=j_idt27]",
            ibNombre: "[name=j_idt27\\:j_idt29]",
            ibPass: "[name=j_idt27\\:j_idt31]",
            wrapper: '#tbClientes',       //place for clientes list <tbody> tag
            dialog:  '#edCliente',
            frmEdit: '#frmCliente',
            btAdd:   '#btCrea',
            btDel:   '#btBorra',
            btCancel:'#btCancela',
            errMsgs: '#errMsgs',          //place for Server-side errors
            srvUrl:  'webservice/clientes'
        };
    }
    init (){
        $(this.config.lista).hide();
        $(this.config.formulario)
            .on('submit', () => {
                return this.validarDatos()
            });
        $(this.config.ibNombre).focus();


        $(this.config.frmEdit).submit( event=> {
            event.preventDefault(); //Avoid default form submit
            this.frmSubmit();
        });
        $(this.config.btAdd).on('click', ()=> {
            this.addCliente();
        });
        $(this.config.btDel).on('click', ()=> {
            this.deleteCliente(this.model.cliente.id);
        });
        $(this.config.btCancel).on('click', ()=> {
            this.frmEditHide();
        });
        $(this.config.wrapper).on('click', event=> {
            //Identify row selected on table click (bubbling event)
            let $selectedRow=$(event.target).parent();
            if ($selectedRow.is('tr'))
                //id for selected cliente is in user-defined attribute
                this.editCliente($selectedRow.attr('data-cliente-id'));
        });

        //Start Showing Clientes
        this.loadClientes();
    }
    validarDatos(){
        let result = true;
        let nombre = $(this.config.ibNombre).val();
        let pass = $(this.config.ibPass).val();
        if (nombre.length < 3 || nombre.length > 20){
            $('#errNombre').text('Error, el nombre debe tener mas de 3 y menos de 20 caracteres');
            result = false;
            console.log("Nombre inválido");
        }
        if (pass == ""){
            $('#errPass').text('Error, la constraseña esta vacia');
            result = false;
            console.log("Contraseña inválido");
        }
        return result;
    }

    addCliente () {
        this.model.errMsgs=[];
        this.model.cliente={id:0,socio:false};
        this.frmEditShow();
    }
    editCliente (id) {
        //Show selected cliente in edit form
        this.model.errMsgs=[];
        //Get cliente from server and update local model
        this.clientesDAO.busca(id)
            .then(cliente=>{
                this.model.cliente=cliente;
                this.frmEditShow();
            })
            .catch( errores => {
                console.log(errores);
                this.model.errMsgs=errores;
                this.showServerErrors();
            });
    }
    frmSubmit () {
        //Create or Update cliente on server
        let cliente = this.model.cliente;

        cliente={};

        //recover cliente data from Form
        cliente.id=$('#id').text();
        cliente.user=$('[name=user]').val();
        cliente.nombre=$('[name=nombre]').val();
        cliente.dni=$('[name=dni]').val();
        cliente.password=$('[name=password]').val();
        cliente.rol=$('[name=rol]').val();
        cliente.saldo=$('[name=saldo]').val();
        cliente.correo=$('[name=correo]').val();
        cliente.apellido=$('[name=apellido]').val();
        cliente.fechaNacimiento=$('[name=fechaNacimiento]').val();

        $(this.config.errMsgs).empty(); //Delete previous server errors

        //Form Client-side validation
        if (this.validateCliente(cliente)) {


            let operacion=null;
            if (cliente.id>0) {
                operacion= this.clientesDAO.guarda(cliente);
            } else {
                operacion=this.clientesDAO.crea(cliente);
            }
            operacion
                .then( json => {
                    console.log(json);
                    this.frmEditHide();
                    this.loadClientes();
                })
                .catch( errores => {
                    console.log(errores);
                    this.model.errMsgs=errores;
                    this.showServerErrors();
                });
        }
    }
    deleteCliente (id=0) {
        this.clientesDAO.borra(id)
            .then(() => {
                this.frmEditHide();
                this.loadClientes();
            })
            .catch(errores  => {
                console.log(errores);
                this.model.errMsgs=errores;
                this.showServerErrors();
            });
    }
    validateCliente (cliente) {
        //Form Client-side validation
        //Shows validation errors next to form fields
        let result = true;
        if (cliente.nombre.length < 4 ) {
            $('#errNombre').show();
            result = false;
        } else {
            $('#errNombre').hide();
        }
        //Further client-side input validations...
        //(ommited for checking server-side validation errors)
        return result;
    }
    frmEditShow () {
        //Shows Edit form
        this.frmEditUpdate();
        this.showServerErrors();
        $(this.config.dialog).modal('show');
    }
    frmEditHide () {
        //Hides Edit form
        $(this.config.dialog).modal('hide');
        //clean previous errors
        $(this.config.errMsgs).empty();
        $('#errNombre').hide();
        $('#errDni').hide();
    }
    frmEditUpdate () {
        //Fill form controls with this.model.cliente data
        let c=this.model.cliente;
        $('#id').text( c.id );
        $('[name=nombre]').val(c.nombre);
        $('[name=dni]').val(c.dni);
        $('[name=user]').val(c.user);
        $('[name=password]').val(c.password);
        $('[name=rol]').val(c.rol);
        $('[name=saldo]').val(c.saldo);
        $('[name=apellido]').val(c.apellido);
        $('[name=correo]').val(c.correo);
        $('[name=fechaNacimiento]').val(c.fechaNacimiento);
    }
    showServerErrors () {
        //Show BeanValidation errors from server-side
        console.log(this.model.errMsgs);
        let errorRows = "";
        this.model.errMsgs.forEach( m => {
            errorRows += "<li class='text-danger'>" + m.message + "</li>";
        });
        $(this.config.errMsgs).html(errorRows);

        this.model.errMsgs=[]; //Clean server errors
    }
    loadClientes () {
        //Get clientes from server and update local model
        this.clientesDAO.buscaTodos()
            .then( clientes => {
                this.model.clientes = clientes;
                this.showClientes(); //force view update
            })
            .catch( errores => {
                console.log(errores);
                this.model.errMsgs=errores;
                this.showServerErrors();
            });
    }
    showClientes () {
        //Fill table with clientes information
        let clientesRows = "";
        this.model.clientes.forEach( c => {
            //Place cliente id in user-defined row attribute for easy access
            //(see table click event)
            clientesRows += "<tr data-cliente-id='"+c.id+"'>";
            clientesRows += "<td>" + c.id + "</td>";
            clientesRows += "<td>" + c.user + "</td>";
            clientesRows += "<td>" + c.password + "</td>";
            clientesRows += "<td>" + c.fechaNacimiento + "</td>";
            clientesRows += "<td>" + c.nombre + "</td>";
            clientesRows += "<td>" + c.apellido + "</td>";
            clientesRows += "<td>" + c.dni + "</td>";
            clientesRows += "<td>" + c.correo + "</td>";
            clientesRows += "<td>" + c.rol + "</td>";
            clientesRows += "<td>" + c.saldo + "</td>";

            clientesRows += "</tr>";
        });
        $(this.config.wrapper).html(clientesRows);
    }
}