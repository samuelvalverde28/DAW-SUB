$( () =>{
    window.ctrl = new articuloPujaCrtl();
    ctrl.init();
});

class articuloPujaCrtl {
    constructor () {
        this.config = {
            lista: "#listaArticulosPuja",
            formulario: "form[name=j_idt27]",
            ibNombre: "[name=j_idt27\\:j_idt29]",
            ibPass: "[name=j_idt27\\:j_idt31]"

        };
    }
    init (){
        $(this.config.lista).hide();
        $(this.config.formulario)
            .on('submit', () => {
                return this.validarDatos()
            });
        $(this.config.ibNombre).focus();

    }
    validarDatos(){
        let result = true;
        let titulo = $(this.config.ibNombre).val();
        let categoria = $(this.config.ibPass).val();
        if (titulo.length < 3 || nombre.length > 20){
            $('#errTitulo').text('Error, el nombre debe tener mas de 3 y menos de 15 caracteres');
            result = false;
            console.log("Título inválida");
        }
        if (categoria == ""){
            $('#errCategoria').text('Error, la categoria está vacía');
            result = false;
            console.log("Categoria inválida");
        }
        return result;
    }


}
