$( () =>{
    window.ctrl = new ClienteCtrl();
    ctrl.init();
});

class ClienteCtrl {
    constructor () {
        this.config = {
          lista: "#listaClientes",
          formulario: "form[name=j_idt27]",
          ibNombre: "[name=j_idt27\\:j_idt29]",
          ibPass: "[name=j_idt27\\:j_idt31]"

        };
    }
    init (){
        $(this.config.lista).hide();
        $(this.config.formulario)
            .on('submit', () => {
                return this.validarDatos()
            });
        $(this.config.ibNombre).focus();

    }
    validarDatos(){
        let result = true;
        let nombre = $(this.config.ibNombre).val();
        let pass = $(this.config.ibPass).val();
        if (nombre.length < 3 || nombre.length > 20){
            $('#errNombre').text('Error, el nombre debe tener mas de 3 y menos de 20 caracteres');
            result = false;
            console.log("Nombre inválido");
        }
        if (pass == ""){
            $('#errPass').text('Error, la constraseña esta vacia');
            result = false;
            console.log("Contraseña inválido");
        }
        return result;
    }


}

