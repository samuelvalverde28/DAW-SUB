$( () =>{
    window.ctrl = new comentarioCtrl();
    ctrl.init();
});

class comentarioCtrl{
    constructor () {
        this.config = {
            comentario: "comentario",
            idComentario: "form[name=j_idt27]"
        };
    }

    validarDatos(){
        let result = true;
        let comentario = $(this.config.comentario).val();
        if (comentario.length < 3 || comentario.length > 40){
            $('#errComentario').text('Error, el comentario debe tener más de 3 caracteres');
            result = false;
            console.log("Comentario invalido");
        }
        return result;
    }


}
