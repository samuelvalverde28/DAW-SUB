package es.ujaen.daw.DAW.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Entity
public class comentario implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_comentario= 0;
    private Integer id_puja = 0;
    private Integer id_cliente = 0;
    @Size(min=3,max=40, message = "La longitud del comentario tiene que ser entre 3 y 40 caracteres")
    private String texto = "";
    private String fecha = "";

    public comentario(){

    }
    public comentario(String _texto){
        this.texto = _texto;

    }

    public comentario(int _id_comentario, int _id_puja, int _id_cliente, String _texto, String _fecha) {
        this.id_comentario = _id_comentario;
        this.id_puja = _id_puja;
        this.id_cliente = _id_cliente;
        this.texto = _texto;
        this.fecha = _fecha;
    }

    public comentario(comentario c){
        this.fecha = c.fecha;
        this.id_comentario = c.id_comentario;
        this.texto = c.texto;
        this.id_cliente = c.id_cliente;
        this.id_puja = c.id_puja;
    }


    public int getId_comentario() {
        return id_comentario;
    }

    public void setId_comentario(int id_comentario) {
        this.id_comentario = id_comentario;
    }

    public int getId_puja() {
        return id_puja;
    }

    public void setId_puja(int id_puja) {
        this.id_puja = id_puja;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
}
