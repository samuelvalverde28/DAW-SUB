package es.ujaen.daw.DAW.model.dao;
import es.ujaen.daw.DAW.model.comentario;

public interface comentarioGenericDAO extends GenericDAO<comentario,Integer>{
    //metodos específicos
}