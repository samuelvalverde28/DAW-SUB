package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.model.Puja;

import javax.enterprise.context.ApplicationScoped;
import java.io.Serializable;
import java.util.*;

@ApplicationScoped
public class PujaDAO implements Serializable {
    private Map<Integer, Puja> pujas;
    private Integer numPujas=1;
    private Integer maxActual =-1;
    private Integer idPujas=1;
    private Integer idArticulo=1;
    private Integer idCliente=100;

    public PujaDAO() {
        if (pujas == null){
            pujas = new HashMap<>();
        }
        pujas.put(idPujas, new Puja(idPujas++,idArticulo++,idCliente++,100));

    }

    public boolean crea(Puja p) {
        Puja p1=new Puja(p);
            if(maxActual<p1.getCantidad() && p1.getCantidad()>0){
                p1.setId_puja(idPujas);
                p1.setId_cliente(idCliente);
                pujas.put(idPujas,p1);
                p.setId_puja(idPujas);
                p.setId_cliente(idCliente);
                maxActual=p1.getCantidad();
                idCliente++;
                idPujas++;
                numPujas++;
                return true;
            }
            return false;
    }

    public boolean borra(Integer idPujaZ) {
        if(buscarPuja(idPujaZ)!=0){
            pujas.remove(idPujaZ);
            numPujas--;
            maxActual=buscaMaximo();
            return true;
        }
        return false;
    }
    /*
    public int numPujas() {
        return pujas.size();
    }
*/
    public List<Puja> buscaTodos() {
        return new ArrayList<>(pujas.values());
    }

/*
    public Integer getMaxActual() {
        return maxActual;
    }
*/
    public Integer getNumPujas() {
        return numPujas;
    }

    public Integer buscaMaximo(){
        maxActual=0;
        Iterator<Integer> it = pujas.keySet().iterator();
        while(it.hasNext()){
            int clave = it.next();
            Puja paux = pujas.get(clave);
            if(paux.getCantidad()>maxActual) maxActual= paux.getCantidad();

        }
        return maxActual;
    }

    //Buscar Puja - Método para buscar Pujas (Utilizado en el Borra)
    public int buscarPuja(Integer idPuja){
        Iterator<Integer> it = pujas.keySet().iterator();
        while(it.hasNext()){
            int clave = it.next();
            Puja paux = pujas.get(clave);
            if(paux.getId_puja()==idPuja) {
                return paux.getId_puja();
            }
        }
        return 0;
    }

}

