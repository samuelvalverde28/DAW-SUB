package es.ujaen.daw.DAW.controller;

import es.ujaen.daw.DAW.model.Puja;
import es.ujaen.daw.DAW.model.dao.PujaDAOJPA;
import es.ujaen.daw.DAW.qualifiers.DAOJPA;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named(value = "pujaCtrl")
@ViewScoped
public class PujaController implements Serializable {
    @Inject @DAOJPA
    private PujaDAOJPA pujaDAO;

    //View-Model
    private Puja puja;
    public PujaController(){}

    @PostConstruct
    public void init() {
        puja = new Puja();
    }

    public Puja getPuja() {
        return puja;
    }


    public void setPuja(Puja puja) {
        this.puja = puja;
    }

    public List<Puja> getPujas() {return pujaDAO.buscaTodos();}

    public String creaPuja() {
        puja.setId_puja(0);
        puja.setId_cliente(100);
        pujaDAO.crea(puja);
        return "vista_puja?faces-redirect=true";
    }

    public String borra(Puja paux) {
        if(pujaDAO.borra(paux.getId_puja())) {
            return "vista_puja?faces-redirect=true";
        }
        return "index";
    }


    public Integer buscaMaximo() {
        return pujaDAO.buscaMaximo();
    }

    public String actualiza(){
        return "vista_puja?faces-redirect=true";
    }

    public Integer numPujas(){
        return pujaDAO.getNumPujas();
    }

    public int buscarPuja(int id){return pujaDAO.buscarPuja(id);}

}
