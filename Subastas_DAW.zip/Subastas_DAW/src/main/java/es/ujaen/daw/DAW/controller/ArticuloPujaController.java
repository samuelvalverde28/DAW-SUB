package es.ujaen.daw.DAW.controller;
import es.ujaen.daw.DAW.model.ArticuloPuja;

import java.io.Serializable;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import es.ujaen.daw.DAW.model.dao.ArticuloPujaGenericDAO;
import es.ujaen.daw.DAW.qualifiers.QUAarticulo;

@Named(value="articuloCtrl")
@ViewScoped
public class ArticuloPujaController implements Serializable {
    @Inject @QUAarticulo
    private ArticuloPujaGenericDAO articuloPujaDAO;
    private final Logger logger = Logger.getLogger(ArticuloPujaController.class.getName());
    private ArticuloPuja articuloPuja;
    public ArticuloPujaController(){};

    @PostConstruct
    public void init(){
        articuloPuja = new ArticuloPuja();
    }

    public ArticuloPuja getArticuloPuja(){

        return  articuloPuja;
    }

    public void setArticuloPuja(ArticuloPuja articuloPuja) {

        this.articuloPuja = articuloPuja;
    }
    public List<ArticuloPuja> getArticulosPujas(){

        return articuloPujaDAO.buscaTodos();
    }
    public void recupera() {

        articuloPuja = articuloPujaDAO.buscaId(articuloPuja.getIdArticuloPuja());
    }


    public String crea() {

        logger.info("creando articulo");
        articuloPuja.setIdArticuloPuja(0);
        articuloPujaDAO.crea(articuloPuja);
        //Post-Redirect-Get
        return "index?faces-redirect=true";
    }

    public String borra() {
        articuloPujaDAO.borra(articuloPuja.getIdArticuloPuja());
        return "index?faces-redirect=true";
    }


    public String borra(ArticuloPuja art) {
        articuloPujaDAO.borra(art.getIdArticuloPuja());
        return "index?faces-redirect=true";
    }

    public Float getPrecio(){
        return articuloPuja.getPrecio();
    }


}
