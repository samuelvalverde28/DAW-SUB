package es.ujaen.daw.DAW.model;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Cliente implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Size(min=3,max=20)
    private String nombre;
    private String apellido;
    @Pattern(regexp = "^\\d{8}([a-zA-Z])$", message = "El formato de DNI no es correcto, Ejemplo: 11111111A")
    private String dni;
    @Pattern(regexp = "^[_A-Za-z0-9-<\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", message="Formato de correo no es correcto, debe seguir la nomenclatura: ejemplo@ejemplo.ejemplo")
    private String correo;
    @Size(min=3,max=20)
    private String user;
    private String password;
    private LocalDate fechaNacimiento;
    private Integer saldo;
    private String descripcion;
    private String rol;

    public Cliente(){
        this.id = 0;
        //this.user = "desconocido";
    }

    public Cliente(Integer id, String nombre, String apellido, String dni, String correo, String user, String password, Integer saldo, String descripcion, String rol) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.correo = correo;
        this.user = user;
        this.password = password;
        this.saldo = saldo;
        this.descripcion = descripcion;
        this.rol = rol;
    }
    public Cliente(Integer id, String nombre, String apellido, String dni, String correo, String user, String password, LocalDate fechaNacimiento, Integer saldo, String descripcion, String rol) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.correo = correo;
        this.user = user;
        this.password = password;
        this.fechaNacimiento = fechaNacimiento;
        this.saldo = saldo;
        this.descripcion = descripcion;
        this.rol = rol;
    }

    /*
     Copy constructor
     */
    public Cliente(Cliente c){
        this.id = c.id;
        this.nombre = c.nombre;
        this.apellido = c.apellido;
        this.dni = c.dni;
        this.correo = c.correo;
        this.user = c.user;
        this.password = c.password;
        this.fechaNacimiento = c.fechaNacimiento;
        this.saldo = c.saldo;
        this.descripcion = c.descripcion;
        this.rol = c.rol;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Integer getSaldo() {
        return saldo;
    }

    public void setSaldo(Integer saldo) {
        this.saldo = saldo;
    }

    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getRol() { return rol; }

    public void setRol(String rol) { this.rol = rol; }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Cliente)) {
            return false;
        }
        Cliente other = (Cliente) object;
        return this.id == other.id;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + this.id;
        return hash;
    }

    @Override
    public String toString() {
        return "Cliente[ id=" + id + " ]";
    }

}