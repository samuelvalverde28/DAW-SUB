package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.model.comentario;
import es.ujaen.daw.DAW.qualifiers.DAOJPA;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@RequestScoped
@DAOJPA
@Transactional
public class comentarioDAOJPA implements comentarioGenericDAO, Serializable {

    private final Logger logger = Logger.getLogger(comentarioDAOJPA.class.getName());

    @PersistenceContext(unitName = "dawPU")

    private EntityManager em;

    public comentarioDAOJPA(){}

    public List<comentario> buscatodos() {
        List<comentario> lc = null;
        try {
            Query q = em.createQuery("Select c from comentario c", comentario.class);
            lc = (List<comentario>) q.getResultList();
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return lc;
    }

    @Override
    public comentario buscaId(Integer id) {
        return null;
    }

    @Override
    public List<comentario> buscaTodos() {
        return null;
    }

    public boolean crea(comentario c) {
        boolean creado = false;
        try {
            em.persist(c);
            creado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return creado;
    }

    @Override
    public boolean guarda(comentario c) {
        return false;
    }

    public boolean borra(Integer id) {
        boolean borrado = false;
        try {
            comentario c = null;
            c = em.find(comentario.class, id);
            em.remove(c);
            borrado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return borrado;
    }
}
