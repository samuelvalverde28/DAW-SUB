package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.qualifiers.DAOJPA;

import javax.enterprise.context.RequestScoped;
import javax.faces.component.html.HtmlCommandScript;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.io.Serializable;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Logger;
import es.ujaen.daw.DAW.model.Puja;
import java.util.List;
import javax.persistence.Query;
import java.util.logging.Level;

@RequestScoped
@DAOJPA
@Transactional
public class PujaDAOJPA implements Serializable {
    private Integer numPujas=2;
    private Integer maxActual =101;
    private Integer idPujas=1;
    private Integer idArticulo=1;
    private Integer idCliente=100;

    private final Logger logger = Logger.getLogger(ClienteDAOJPA.class.getName());

    @PersistenceContext(unitName = "dawPU")

    private EntityManager em;

    public PujaDAOJPA(){}

    public List<Puja> buscaTodos() {
        List<Puja> lc = null;
        try {
            Query q = em.createQuery("Select c from Puja c", Puja.class);
            lc = (List<Puja>)q.getResultList();
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return lc;
    }


    public boolean crea(Puja c) {
        boolean creado = false;
        try {
            buscaMaximo();
            numPujas++;//No actualiza
            if(c.getCantidad() > maxActual){
                em.persist(c);
                creado = true;
            }else{
                return false;
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return creado;
    }


    public boolean borra(Integer id) {
        boolean borrado = false;
        buscaMaximo();
        numPujas--;
        try {
            Puja c = null;
            c = em.find(Puja.class, id);
            em.remove(c);
            borrado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return borrado;
    }

    public Integer getNumPujas() {return numPujas;}


    public Integer buscaMaximo(){
        Query p = em.createQuery("Select MAX(c.cantidad) from Puja c", Puja.class);
        maxActual = (int) p.getSingleResult();
        return maxActual;
    }


    public int buscarPuja(Integer idPuja){
        Puja c = null;
        c = em.find(Puja.class, idPuja);
            if(c.getId_puja()==idPuja) {
                return idPuja;
            }
        return 0;
    }

    //enlazar tablas para filtrar en las pujas por el articulo de tal forma que a cada articulo solo le salgan sus pujas + imagen,descip,etc

}
