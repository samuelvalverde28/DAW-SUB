package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.model.Cliente;

public interface ClienteGenericDAO extends GenericDAO<Cliente,Integer> {
    //Se declaran los metodos especificos
    public String damePassword(String username);
    public String dameRol(String username);
}
