package es.ujaen.daw.DAW.model.dao;
import es.ujaen.daw.DAW.model.ArticuloPuja;

public interface ArticuloPujaGenericDAO extends GenericDAO<ArticuloPuja,Integer>{
    //metodos específicos
}
