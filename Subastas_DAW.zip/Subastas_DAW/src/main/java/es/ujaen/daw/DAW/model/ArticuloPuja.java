package es.ujaen.daw.DAW.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

@Entity
public class ArticuloPuja  implements Serializable{

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer idArticuloPuja;

private String foto;

@Size(min=3,max=15, message = "La longitud del titulo tiene que ser entre 3 y 15 caracteres")
private String titulo;

private String descripcion;

@Size(min=3,max=10, message = "La longitud de la categoria tiene que ser entre 3 y 10 caracteres")
private String categoria;
private Float precio;
private String fecha;

public ArticuloPuja() {
    this.idArticuloPuja = 0;
    this.foto = "SinImagen.png";
}

public ArticuloPuja(Integer idArticuloPuja, String foto, String titulo, String categoria, String descripcion, Float precio, String fecha){
   this.idArticuloPuja=idArticuloPuja;
   this.foto=foto;
   this.titulo=titulo;
   this.categoria=categoria;
   this.descripcion=descripcion;
   this.precio=precio;
   this.fecha=fecha;

}

public ArticuloPuja(ArticuloPuja orig){
    this.idArticuloPuja=orig.idArticuloPuja;
    this.foto=orig.foto;
    this.titulo=orig.titulo;
    this.categoria=orig.categoria;
    this.descripcion=orig.descripcion;
    this.precio=orig.precio;
    this.fecha=orig.fecha;
}


    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    public Integer getIdArticuloPuja() {
        return idArticuloPuja;
    }

    public void setIdArticuloPuja(Integer idArticuloPuja) {
        this.idArticuloPuja = idArticuloPuja;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ArticuloPuja)) return false;
        ArticuloPuja that = (ArticuloPuja) o;
        return Objects.equals(getIdArticuloPuja(), that.getIdArticuloPuja()) && Objects.equals(getFoto(), that.getFoto()) && Objects.equals(getTitulo(), that.getTitulo()) && Objects.equals(getDescripcion(), that.getDescripcion()) && Objects.equals(getCategoria(), that.getCategoria()) && Objects.equals(getPrecio(), that.getPrecio()) && Objects.equals(getFecha(), that.getFecha());
    }

    @Override
    public int hashCode() {
    int hash = 7;
    hash = 11 * hash + this.idArticuloPuja;
        return Objects.hash(getIdArticuloPuja(), getFoto(), getTitulo(), getDescripcion(), getCategoria(), getPrecio(), getFecha());
    }

    @Override
    public String toString() {
        return "ArticuloPuja{" +
                "idArticuloPuja=" + idArticuloPuja +
                ", foto='" + foto + '\'' +
                ", titulo='" + titulo + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", categoria='" + categoria + '\'' +
                ", precio=" + precio +
                ", fecha='" + fecha + '\'' +
                '}';
    }
}
