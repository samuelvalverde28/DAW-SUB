package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.model.Cliente;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class ClienteDAO implements Serializable {
    private Map<Integer, Cliente> clientes = null;
    private int idCliente = 1; //last clientID

    public ClienteDAO() {
        if (clientes == null){
            clientes = new HashMap<>();
        }
        clientes.put(idCliente, new Cliente(idCliente++, "Paco", "López" , "11111111A", "pacolopez@gmail.com","plopez","1111", 500, "Buena persona, creo", "Usuario"));
        clientes.put(idCliente, new Cliente(idCliente++, "María", "Jiménez" , "11111112A", "mariajimenez@gmail.com","mjimenez","1111", 501, "Buena persona, creo", "Usuario"));
        clientes.put(idCliente, new Cliente(idCliente++, "Carlos", "García" , "11111113A", "carlosgarcia@gmail.com","cgarcia","1111", 502, "Buena persona, creo", "Usuario"));
    }

    public boolean crea(Cliente c) {
        Cliente nc=new Cliente(c);
        nc.setId(idCliente);
        clientes.put(idCliente, nc);
        c.setId(idCliente);
        idCliente++;
        return true;
    }

    public boolean borra(Integer id) {
        boolean result=false;
        if (clientes.containsKey(id)) {
            clientes.remove(id);
            result = true;
        }
        return result;
    }

    public boolean guarda(Cliente c) {
        boolean result=false;
        if (clientes.containsKey(c.getId())) {
            Cliente nc=new Cliente(c);
            clientes.replace(c.getId(),c);
            result=true;
        }
        return result;
    }



    public int numClientes() {
        return clientes.size();
    }

    public List<Cliente> buscaTodos() {
        return clientes.values().stream().collect(Collectors.toList());
    }

    public Cliente buscaId(Integer id) {
        Cliente localizado = clientes.get(id);
        if (localizado != null) localizado= new Cliente(localizado);
        return localizado;
    }

    public String descripcion(Integer id){
        Cliente c = buscaId(id);
        return c.getDescripcion();
    }
}
