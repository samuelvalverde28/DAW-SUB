package es.ujaen.daw.DAW;

import es.ujaen.daw.DAW.model.Cliente;

import javax.ws.rs.*;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@ApplicationPath("api") //Service URL: /api/*
public class SubastaJAXRSConfig extends Application {

}


