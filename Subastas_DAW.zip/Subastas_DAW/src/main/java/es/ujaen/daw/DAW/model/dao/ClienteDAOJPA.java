package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.model.Puja;
import es.ujaen.daw.DAW.qualifiers.DAOJPA;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.Iterator;
import java.util.logging.Logger;
import es.ujaen.daw.DAW.model.Cliente;
import java.util.List;
import javax.persistence.Query;
import java.util.logging.Level;

@RequestScoped
@DAOJPA
@Transactional
public class ClienteDAOJPA implements ClienteGenericDAO,Serializable {


    private final Logger logger = Logger.getLogger(PujaDAOJPA.class.getName());

    @PersistenceContext(unitName = "dawPU")

    private EntityManager em;

    public ClienteDAOJPA(){}

    @Override
    public List<Cliente> buscaTodos() {
        List<Cliente> lc = null;
        try {
            Query q = em.createQuery("Select c from Cliente c", Cliente.class);
            lc = (List<Cliente>)q.getResultList();
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return lc;
    }

    @Override
    public Cliente buscaId(Integer id) {
        Cliente c=null;
        try {
            c=em.find(Cliente.class, id);
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);

        }
        return c;
    }

    @Override
    public boolean crea(Cliente c) {
        boolean creado = false;
        try {
            em.persist(c);
            creado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return creado;
    }

    @Override
    public boolean guarda(Cliente c) {
        boolean guardado = false;
        try {
            c = em.merge(c);
            guardado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return guardado;
    }

    @Override
    public boolean borra(Integer id) {
        boolean borrado = false;
        try {
            Cliente c = null;
            c = em.find(Cliente.class, id);
            em.remove(c);
            borrado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return borrado;
    }

    @Override
    public String damePassword(String user){
        List<Cliente> lc = null;
        Cliente c=null;
        String contra="";
        try {
            Query q = em.createQuery("Select c.password from Cliente c WHERE c.user = :custUser", Cliente.class).setParameter("custUser",user);
            lc = (List<Cliente>)q.getResultList();
            contra = lc.toString().replaceAll("\\[|\\]", "");
            //logger.log(Level.INFO, "aaaaaaaaaaaaaaaa "+contra);
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);

        }
        return contra;
    }

    @Override
    public String dameRol(String user){
        List<Cliente> lc = null;
        Cliente c=null;
        String rol="";
        try {
            Query q = em.createQuery("Select c.rol from Cliente c WHERE c.user = :custUser", Cliente.class).setParameter("custUser",user);
            lc = (List<Cliente>)q.getResultList();
            rol = lc.toString().replaceAll("\\[|\\]", "");
            //logger.log(Level.INFO, "aaaaaaaaaaaaaaaa "+contra);
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return rol;
    }


}
