package es.ujaen.daw.DAW.controller;

import es.ujaen.daw.DAW.model.Cliente;
import es.ujaen.daw.DAW.model.dao.ClienteDAOJPA;
import es.ujaen.daw.DAW.model.dao.ClienteGenericDAO;
import es.ujaen.daw.DAW.qualifiers.DAOJPA;

import java.io.Serializable;
import java.util.List;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;


@Named(value = "clienteCtrl")
@ViewScoped
public class ClienteController implements Serializable {

    //private static final long serialVersionUID = 1L;
    private final Logger logger = Logger.getLogger(ClienteController.class.getName());

    @Inject @DAOJPA
    private ClienteGenericDAO clienteDAO;

    //View-Model
    private Cliente cliente;
    public ClienteController() {}

    @PostConstruct
    public void init() {
        //init  model-view
        cliente = new Cliente();
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }

    public List<Cliente> getClientes() {
        return clienteDAO.buscaTodos();
    }

    //ACTIONS for visualiza, crea, edit and borra views

    /**
     * Get client from id param
     */
    public void recupera() {
        cliente = clienteDAO.buscaId(cliente.getId());
    }

    /**
     * Create a new Client from model data
     */
    public String crea() {
        logger.info("creando usuario");
        cliente.setId(0);
        cliente.setSaldo(100);
        cliente.setRol("Usuario");
        clienteDAO.crea(cliente);
        return "index?faces-redirect=true";
    }

    /**
     * Delete current model data client
     */
    public String borra() {
        logger.info("borrando cliente normal");
        clienteDAO.borra(cliente.getId());
        return "index";
    }


    //ACTIONS for index.xhtml view
    public String borra(Cliente cliente) {
        logger.info("borrando cliente");
        clienteDAO.borra(cliente.getId());
        return "clientes?faces-redirect=true";
    }

    /**
     * Update current model client to DAO
     */
    public String guarda() {
        clienteDAO.guarda(cliente);
        return "clientes?faces-redirect=true";
    }


    @Inject HttpServletRequest request;
    public String logout() throws ServletException {
        request.logout();
        request.getSession().invalidate();
        return "/index?faces-redirect=true";
    }


}