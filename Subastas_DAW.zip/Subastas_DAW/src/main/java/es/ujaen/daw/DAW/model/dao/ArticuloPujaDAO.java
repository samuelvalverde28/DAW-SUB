package es.ujaen.daw.DAW.model.dao;
import es.ujaen.daw.DAW.model.ArticuloPuja;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import es.ujaen.daw.DAW.model.ArticuloPuja;


@ApplicationScoped
public  class ArticuloPujaDAO implements Serializable {
    private Map<Integer, ArticuloPuja> articulosPujas = null;
    private Integer id_art=1;

    public ArticuloPujaDAO(){
        if(articulosPujas == null ){
            articulosPujas = new HashMap<>();
        }
        articulosPujas.put(id_art,new ArticuloPuja(id_art++,"iphone12.jpg","titulo1","categoria1","descripcion1", Float.valueOf(1), "fecha1"));
        articulosPujas.put(id_art,new ArticuloPuja(id_art++,"ordenador.jpg","titulo2","categoria2","descripcion2", Float.valueOf(2), "fecha2"));
        articulosPujas.put(id_art,new ArticuloPuja(id_art++,"iphone12.jpg","titulo3","categoria3","descripcion3", Float.valueOf(3), "fecha3"));
    }
   public List<ArticuloPuja> buscaTodos(){

        return articulosPujas.values().stream().collect(Collectors.toList());
   }
   public ArticuloPuja buscaId(Integer id){

        return new ArticuloPuja (articulosPujas.get(id));
   }

    public boolean crea(ArticuloPuja a) {
        ArticuloPuja na=new ArticuloPuja(a);
        na.setIdArticuloPuja(id_art);
        articulosPujas.put(id_art,na);
        a.setIdArticuloPuja(id_art);
        id_art++;
        return true;
    }



    public boolean borra(Integer idArticuloPuja){
        boolean result = false;
        if(articulosPujas.containsKey(idArticuloPuja)){
            articulosPujas.remove(idArticuloPuja);
            result = true;
        }
        return result;
    }

}


