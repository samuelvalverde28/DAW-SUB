package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.model.ArticuloPuja;
import es.ujaen.daw.DAW.qualifiers.DAOJPA;
import es.ujaen.daw.DAW.qualifiers.QUAarticulo;

import javax.enterprise.context.RequestScoped;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.io.Serializable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@RequestScoped
@QUAarticulo
@Transactional
public class ArticuloPujaDAOJPA implements ArticuloPujaGenericDAO,Serializable {
    private final Logger logger = Logger.getLogger(ArticuloPujaDAOJPA.class.getName());

    @PersistenceContext(unitName = "dawPU") //Only for JEE full application servers
    //Requires to enable Persistence-unit in persistence.xml
    private EntityManager em;

    public ArticuloPujaDAOJPA() {
    }
@Override
    public ArticuloPuja buscaId(Integer id) {
        ArticuloPuja c=null;
        try {
            c=em.find(ArticuloPuja.class, id);
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);

        }
        return c;
    }
    @Override
    public List<ArticuloPuja> buscaTodos() {
        List<ArticuloPuja> lc = null;
        try {
            Query q = em.createQuery("Select c from ArticuloPuja c", ArticuloPuja.class);
            lc = (List<ArticuloPuja>)q.getResultList();
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return lc;
    }

    @Override
    public boolean crea(ArticuloPuja c) {
        boolean creado = false;
        try {
            em.persist(c);
            creado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return creado;
    }
    @Override
    public boolean guarda(ArticuloPuja c) {
        boolean guardado = false;
        try {
            c = em.merge(c);
            guardado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return guardado;
    }
    @Override
    public boolean borra(Integer id) {
        boolean borrado = false;
        try {
            ArticuloPuja c = null;
            c = em.find(ArticuloPuja.class, id);
            em.remove(c);
            borrado = true;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, ex.getMessage(), ex);
        }
        return borrado;
    }

}
