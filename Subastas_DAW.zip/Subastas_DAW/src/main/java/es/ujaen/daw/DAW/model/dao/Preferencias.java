package es.ujaen.daw.DAW.model.dao;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import java.io.Serializable;

@Named(value="prefs")
@SessionScoped
public class Preferencias implements Serializable {
    private String rol="";

    public Preferencias(){};

    public  String getRol() {return rol;}
    public void setRol(String rol) {this.rol = rol;}
}
