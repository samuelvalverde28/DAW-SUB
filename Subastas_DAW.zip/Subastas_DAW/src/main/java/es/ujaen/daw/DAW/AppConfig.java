package es.ujaen.daw.DAW;



import javax.enterprise.context.ApplicationScoped;
import javax.faces.annotation.FacesConfig;
import javax.security.enterprise.authentication.mechanism.http.BasicAuthenticationMechanismDefinition;
import org.glassfish.soteria.identitystores.annotation.Credentials;
import org.glassfish.soteria.identitystores.annotation.EmbeddedIdentityStoreDefinition;

import javax.security.enterprise.authentication.mechanism.http.CustomFormAuthenticationMechanismDefinition;
import javax.security.enterprise.authentication.mechanism.http.FormAuthenticationMechanismDefinition;
import javax.security.enterprise.authentication.mechanism.http.LoginToContinue;


@EmbeddedIdentityStoreDefinition({
        @Credentials(callerName = "admin", password = "secret1", groups = {"ADMINISTRADORES"}),
        @Credentials(callerName = "user", password = "secret2", groups = {"USUARIOS"})
})

//@BasicAuthenticationMechanismDefinition( realmName = "Pujas DAW")
/*@FormAuthenticationMechanismDefinition(
        loginToContinue = @LoginToContinue(
                loginPage = "/vistalogin.xhtml",
                errorPage = "/vistalogin.xhtml?error",
                useForwardToLogin = false
        )
)*/
@CustomFormAuthenticationMechanismDefinition(
        loginToContinue = @LoginToContinue(
                loginPage = "/vistalogin.xhtml",
                errorPage = "/vistalogin.xhtml?error",
                useForwardToLogin = false
        )
)
@ApplicationScoped
@FacesConfig //Required for using JSF 2.3 features
public class AppConfig {

}
