package es.ujaen.daw.DAW.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.*;

@Entity
public class Puja implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id_puja;
    private Integer id_cliente;
    private Integer id_articulo;
    @Min(1)
    @Max(99999)
    private Integer cantidad;

    public Puja() {
        id_puja=0;
    }
    public Puja(Integer a) {

        id_articulo=0;
        id_puja=0;
        id_cliente=0;
        cantidad=a;
    }

    public Puja(Integer _id_puja, Integer _id_articulo,Integer _id_cliente, Integer _cantidad){

        id_articulo=_id_articulo;
        id_puja=_id_puja;
        id_cliente=_id_cliente;
        cantidad=_cantidad;
    }

    public Puja(Puja orig){
                id_articulo=orig.id_articulo;
                id_puja=orig.id_puja;
                id_cliente=orig.id_cliente;
                cantidad=orig.cantidad;
    }

    //public Puja getPuja(){return this; }

    public Integer getId_puja() {
        return id_puja;
    }

    public void setId_puja(Integer id_puja) {
        this.id_puja = id_puja;
    }

    public Integer getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(Integer id_cliente) {
        this.id_cliente = id_cliente;
    }

    public Integer getId_articulo() {
        return id_articulo;
    }

    public void setId_articulo(Integer id_articulo) {
        this.id_articulo = id_articulo;
    }



    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
}