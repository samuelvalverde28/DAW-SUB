package es.ujaen.daw.DAW.model.dao;

import es.ujaen.daw.DAW.model.comentario;

import javax.enterprise.context.ApplicationScoped;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@ApplicationScoped
public class comentarioDAO implements Serializable {

    private Map<Integer, comentario> comentarios = null;
    private Integer id_comentario = 1;
    private Integer id_puja = 1;
    private Integer id_cliente = 1;

    public comentarioDAO(){
        if (comentarios == null){
            comentarios = new HashMap<>();
        }
        comentarios.put(id_comentario, new comentario(id_comentario++, id_puja++, id_cliente++, "Comentario por defecto", "22/03/22"));

    }

    /*Método para añadir un comentario al mapa*/
    public boolean crea(comentario c){
        comentario nc = c;
        nc.setId_comentario(id_comentario);
        comentarios.put(id_comentario, nc);
        c.setId_comentario(id_comentario);
        id_comentario++;
        return true;
    }

    /*Método para eliminar un comentario del mapa*/
    public boolean borra(Integer id){
        boolean result = false;
        //Comprobamos que el comentario se encuentre en el mapa
        if(comentarios.containsKey(id)){
            comentarios.remove(id);
            result = true;
        }
        return result;
    }

    public int numComentarios(){
        return comentarios.size();
    }

    public List<comentario> buscatodos(){
        return comentarios.values().stream().collect(Collectors.toList());
    }

}
