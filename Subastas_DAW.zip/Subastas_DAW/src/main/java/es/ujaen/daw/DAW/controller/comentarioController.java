package es.ujaen.daw.DAW.controller;

import es.ujaen.daw.DAW.model.comentario;
import es.ujaen.daw.DAW.model.dao.comentarioDAO;
import es.ujaen.daw.DAW.model.dao.comentarioDAOJPA;
import es.ujaen.daw.DAW.qualifiers.DAOJPA;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;
import java.util.logging.Logger;

@Named(value="comentarioCtrl")
@ViewScoped
public class comentarioController implements Serializable {

    @Inject @DAOJPA
    private comentarioDAOJPA comentDAO;

    private comentario coment;
    private Integer id_comentario = 3;
    private final Logger logger = Logger.getLogger(comentarioController.class.getName());
    public comentarioController(){}

    @PostConstruct
    public void init(){
        setComent(new comentario());
    }

    public List<comentario> getcomentarios(){
        return comentDAO.buscatodos();
    }

    public String crea(){
        logger.info("creando comentario");
        getComent().setId_comentario(id_comentario);
        id_comentario++;
        coment.setId_comentario(id_comentario);
        comentDAO.crea(coment);
        return "vista_puja?faces-redirect=true";
    };

    public String borra(){
        logger.info("borrando comentario normal");
        comentDAO.borra(coment.getId_comentario());
        return "comentarios?faces-redirect=true";
    }

    public String borra(comentario c){
        logger.info("borrando comentario");
        comentDAO.borra(c.getId_comentario());
        return "comentarios?faces-redirect=true";
    }

    public comentario getComent() {
        return coment;
    }

    public void setComent(comentario coment) {
        this.coment = coment;
    }
}
