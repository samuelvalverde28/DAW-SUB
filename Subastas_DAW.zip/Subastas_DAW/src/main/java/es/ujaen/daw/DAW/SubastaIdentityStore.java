package es.ujaen.daw.DAW;

import es.ujaen.daw.DAW.controller.ClienteLoginController;
import es.ujaen.daw.DAW.model.dao.ClienteGenericDAO;
import es.ujaen.daw.DAW.model.dao.Preferencias;
import es.ujaen.daw.DAW.qualifiers.DAOJPA;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.security.enterprise.credential.UsernamePasswordCredential;
import javax.security.enterprise.identitystore.CredentialValidationResult;
import javax.security.enterprise.identitystore.IdentityStore;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.Level;

import static javax.security.enterprise.identitystore.CredentialValidationResult.INVALID_RESULT;



@ApplicationScoped
public class SubastaIdentityStore implements IdentityStore {
    private static final Logger logger = Logger.getLogger(ClienteLoginController.class.getName());
    private Map<String, String> credenciales; //ejemplo de almacén de credenciales

    @Inject
    @DAOJPA
    private ClienteGenericDAO clienteDAO;


    @Inject
    Preferencias preferencias;

    public SubastaIdentityStore() {
        credenciales = new HashMap<>();
        credenciales.put("usuario", "clave");
        credenciales.put("usuario2", "clave2");
    }

    public CredentialValidationResult validate (
            UsernamePasswordCredential usernamePasswordCredential ) {
//Recuperar credenciales proporcionadas por el servidor
        String username = usernamePasswordCredential.getCaller();
        String password = usernamePasswordCredential.getPasswordAsString();

        String contra = clienteDAO.damePassword(username);
        String rol = clienteDAO.dameRol(username);
        logger.log(Level.INFO, "punto de inflexion info rol "+rol);
        //logger.log(Level.INFO, "punto de inflexion info pass "+contra);
        //logger.log(Level.INFO, "punto de inflexion username "+username);
        //logger.log(Level.INFO, "punto de inflexion password "+password);
        if(contra.length() != 0){
            //logger.log(Level.INFO, "punto de inflexion");
            if (password.equals(contra)) {
                //logger.log(Level.INFO, "punto de inflexion 2");
                //Autenticación completada, obtener los roles del usuario...

                String a[] = new String[1];
                a[0] = "USUARIOS";
                if (rol.equals("Administrador")){
                    a[0] = "ADMINISTRADORES";
                    preferencias.setRol("Administrador");
                }
                //logger.log(Level.INFO, a[0]);
                Set<String> roles = new HashSet<>(Arrays.asList(a));
                //Pasar datos del usuario al servidor
                return new CredentialValidationResult(username, roles);
            }
            //logger.log(Level.INFO, "punto de inflexion 3");

        }
        //logger.log(Level.INFO, "punto de inflexion password 0");

        return INVALID_RESULT; //Autenticación inválida
    }


}