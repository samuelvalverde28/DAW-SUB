insert into comentario(id_comentario, texto) values (01,'Prueba de texto');
insert into comentario(id_comentario, texto) values (02,'Prueba dos de texto');

insert into ArticuloPuja (foto, titulo, categoria, descripcion, precio, fecha) VALUES ('iphone12.jpg','titular1','categorize1','description1',1, '2022-01-01');
insert into ArticuloPuja (foto, titulo, categoria, descripcion, precio, fecha) VALUES ('SinImagen.png','titular2','categorize1','description1',1, '2022-01-01');

insert into Cliente (nombre, apellido, user, password, correo, dni, fechaNacimiento, saldo, rol) VALUES ('Administrador','','admin','1234','admin@gmail.com','11111111A', '1999-04-04', 500, 'Administrador');
insert into Cliente (nombre, apellido, user, password, correo, dni, fechaNacimiento, saldo, rol) VALUES ('Paco','López','plopez','1234','pacolopez@gmail.com','11111111B', '1999-04-04', 500, 'Usuario');
insert into Cliente (nombre, apellido, user, password, correo, dni, fechaNacimiento, saldo, rol) VALUES ('María','Jiménez','mjimenez','1234','mariajimenez@gmail.com','11111111C', '1999-04-04', 500, 'Usuario');
insert into Cliente (nombre, apellido, user, password, correo, dni, fechaNacimiento, saldo, rol) VALUES ('Carlos','García','cgarcia','1234','carlosgarcia@gmail.com','11111111D', '1999-04-04', 500, 'Usuario');

insert into Puja (id_puja,id_cliente,id_articulo,cantidad) VALUES (01,100,1001,100);
insert into Puja (id_puja,id_cliente,id_articulo,cantidad) VALUES (02,101,1200,101);