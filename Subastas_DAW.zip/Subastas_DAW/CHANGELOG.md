# Registro de cambios
Todos los cambios notables en este proyecto se documentarán en este archivo, con sus respectivas fechas de entrega y nombres de cada miembro 
con sus respectivos cambios.


## Iteración 1 - [11/03/2022]

Samuel - Creación de la vista, General.xhtml e Index.xhtml con sus respectivos diseños css.

Guillermo - Creación de la vista articulo.xhtml y vistalogin.xhtml con los css correspondientes.

Andres - Cración de la vista vista_puja.xhtml con su css correspondiente.

David - Creación de la vista perfil.xhtml con su correspondiente archivo css.

## Iteración 2 - [25/03/2022]

Samuel - Creación de CRUD del Dao y controller de clientes, cambio de la vista login, perfil y creacion de la vista editaCliente.

Guillermo - Creación de la clase articuloPuja, controller, y DAO. Modificación de index.xhtml para la correcta implementación de las clases creadas en java.

Andrés - Creación de la Clase, del Controller y del DAO de "Puja", cambio en la vista vista_puja para su correcto funcionamiento.

David - Creación de la clase comentario, controller y DAO. Modificación del fichero vista_perfil.xhtml para su correcto funcionamiento.

## Iteración 3 - [08/04/2022]

Guillermo - Creación de clase articuloPujaDAOJpa. Modificación del css para el formulario de articuloPuja y algunas mejoras en index.

David - Creación del fichero comentarioDAOJPA, creación de la entidad comentario en la base de datos, con clave primaria(id_comentario) y adaptación del controller de comentario para su correcto funcionamiento con la base de datos.

Samuel - Creación de la clase clienteDAOJPA, creación de DAO generico, creacion de autenticación con J_security_check (Error en el autenticacion por el controller), creacion de la gestión de sesiones (Cookie), creacion de la desconexión, cambio de estilos para la vista login y editaCliente.

Andrés - Modificación clase Puja y PujaController, creación de PujaDAOJPA y de la base de datos para Puja, actualización del fichero sampledata.sql con insert de prueba.

## Iteración 4 - [29/04/2022]

Samuel - Cambio del Login de J_security_check a IdentityStore y uso de los roles para que la vista de clientes solo esté accesible para los roles administradores.

Guillermo - Implementación de la clase ArticuloPuja en el dao genérico.

David - Implementación de la clase comentario en el dao genérico.


## Iteración 5 - [14/05/2022]

Guillermo - Uso de js para validar la categoria y el título del cliente.

David - Modificado el contador de la vista puja, por uno real con javascript que muestra la cuenta regresiva, también se ha añadido un pequeño contador en la portada de cada articulo, indicando el tiempo restante, solucionado error que no actualizaba el precio tras realizar una puja, añadido comentarioController.js, se muestra un mensaje de error cuando un texto no es valido

Samuel - Uso de js para validar datos del login desde el cliente, creación del servicio web REST con JAX-RS para los clientes ( /api/* ), creación de la aplicación web de los cliente (cliente.html) con intercambio de datos AJAX con el servicio web.